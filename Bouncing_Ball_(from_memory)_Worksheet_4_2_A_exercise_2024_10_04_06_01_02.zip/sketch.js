x=0
y=30
speedx=8
speedy=2
//angle=0
function setup() {
  createCanvas(windowWidth,windowHeight);
  angleMode(DEGREES);
}

function draw() {
  background(220);
  //rotate(angle)
  stroke(0)
  fill(25,100,200)
  ellipse(x,100,50,50)
  if(x>width){
    speedx=-speedx
  } 
  
  
  x=x+speedx
 // angle=angle-1
}