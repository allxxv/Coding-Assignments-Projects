let r, g, b;
function setup() {
  createCanvas(400, 400);
  background(0);

}

function draw() {
  r = random(255);
  g = random(255);
  b = random(255);
  
  noStroke();
  fill(r,g,b,50);
  ellipse(mouseX,mouseY,24);
  
  function mousePressed() {
  ellipse(r,g,b,255);
  }
}
  