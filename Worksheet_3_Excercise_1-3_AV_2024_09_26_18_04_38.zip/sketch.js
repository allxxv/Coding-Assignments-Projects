let x1, x2;
let y1, y2;

function setup() {
  createCanvas(windowWidth, windowHeight);
  x1 = width / 4;
  x2 = (3 * width) / 4;
  y1 = height / 4;
  y2 = (3 * height) / 4;
  angleMode(DEGREES);
}

function draw() {
  background(0);
  stroke(300);
  fill(100, 110, 200);
  rectMode(CENTER);
  rect(width / 2, height / 2, width / 2, height / 2);

  line(x1, y1, x2, y1); //horizontal line at top (y is the same)

  line(x2, y1, x2, y2); //right vertical line (x is the same)

  line(x1, y2, x2, y2); //second horizontal line at bottom (y is the same)

  line(x1, y1, x1, y2); //left vertical line (x is the same)

  push();
  let x = frameCount * 3;
  translate(x, 20);
  fill(200, 0, 0, 170);
  circle(width / 2, height / 2, width / 8);
  pop();

  push();
  fill(0, 0, 200, 170);
  translate(-x, 0);
  circle(width / 2, height / 2, width / 8);
  pop();

  push();
  fill(0, 200, 0, 170);
  translate(0, -x);
  circle(width / 2, height / 2, width / 8);
  pop();

  push();
  fill(200, 200, 0, 170);
  translate(0, x);
  circle(width / 2, height / 2, width / 8);
  pop();

  push();
  let y = frameCount * 10;
  fill(150, 0, 150, 170);
  rotate(45);
  translate(170, -y);
  circle(width / 2, height / 2, width / 8);
  pop();

  push();
  y = frameCount * 3;
  fill(200, 80, 0, 170);
  rotate(45);
  translate(-x, -205);
  circle(width / 1, height / 4, width / 8);
  pop();

  push();
  frameCount * 3;
  fill(50, 130, 230, 170);
  rotate(45);
  translate(x, -90);
  circle(width / 15, height / 8, width / 8);
  pop();

  push();
  frameCount * 3;
  fill(50, 0, 50, 170);
  rotate(45);
  translate(570, y);
  circle(width / 13, height / 15, width / 8);
  pop();
}
