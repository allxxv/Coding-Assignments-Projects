function setup() {
  createCanvas(400, 400);
  background(230)
  rect(130,130,150,150);
  noLoop();
}

function draw() {}

function mouseReleased() {
  fill(0);
  rect(130,130,150,150);
}
