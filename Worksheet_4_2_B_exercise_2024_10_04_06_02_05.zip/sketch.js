let x = 100; //starting
let y = 100; //starting
let speedx = -18; // x speed
let speedy = 4; // y speed
let diameter = 50; // ball diameter
//let random=(r,g,b);
//let r= (255,0,0)
//let b=(0,0,255)
//let g= (0,255,0)

function setup() {
  createCanvas(windowWidth, windowHeight);
  angleMode(DEGREES);
}

function draw() {
  background(40,40);
  
  // Update ball position
  x += speedx;
  y += speedy;
  
  // left and right
  if (x > width - diameter / 2 || x < diameter / 2) {
    speedx = -speedx; 
  }
  
  // up and down
  if (y > height - diameter / 2 || y < diameter / 2) {
    speedy = -speedy;
    //fill(random)
  }
  
  // ball
  fill(25, 140, 100);
  noStroke();
  ellipse(x, y, diameter, diameter);
  //ball2
  //fill(25, 140, 100);
 // noStroke();
  //ellipse(x, y, diameter/2, diameter/2);
}

// Paint
function mouseClicked() {
  print(150, 20, 200); 
  ellipse(mouseX, mouseY, diameter, diameter); 
}
