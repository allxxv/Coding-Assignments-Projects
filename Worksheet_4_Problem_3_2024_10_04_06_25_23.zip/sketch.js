let x = 0;
let speed = 3;
let ellipseColor;
let rectColor;

function setup() {
  createCanvas(600, 400);

  ellipseColor = color(random(255), random(255), random(255));
  rectColor = color(random(255), random(255), random(255));
}

function draw() {
  background(0);
  stroke(255);

  

  fill(ellipseColor);
  ellipse(x, 200, 100, 100);


  fill(rectColor);
  rect(230, 60, 150, 250); 

  //collision reference tutorial to remember
  if (x + 50 > 250 &&
      x - 50 < 350 && 
      200 + 50 > 150 && 
      200 - 50 < 200) {
    
    ellipseColor = color(random(255), random(255), random(255));
    rectColor = color(random(255), random(255), random(255));
  }

  if (x > width) {
    speed = -6;
  } else if (x < 0) { 
    speed = 3;
  }
  
  x = x + speed; 
}
