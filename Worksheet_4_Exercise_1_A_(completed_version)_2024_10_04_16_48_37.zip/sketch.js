//declare variable for the button
let rectX, rectY;
let rectWidth, rectHeight;
let x = 20;
let speed = 4;
let r = 0;
let g = (0, 255, 0);
let b = (0, 0, 255);
let re = (255, 0, 0);
let bb = false;

function setup() {
  createCanvas(400, 400);
  rectMode(CENTER);

  //give rectangle variables values
  rectX = width / 2;
  rectY = width / 2;
  rectWidth = 50;
  rectHeight = 50;
  rectColor = (re, g, b, r);
  re = random(255);
  g = random(255);
  b = random(255);
  r = random(255);
}

function draw() {
  background(220);
  //is it inside the button for the first time?

  if ( mouseX > rectX - rectWidth / 2 &&
    mouseX < rectX + rectWidth / 2 &&
    mouseY > rectY - rectHeight / 2 &&
    mouseY < rectY + rectHeight / 2&&
      bb == false) {
    //true
    r = random(255);
    g = random(255);
    b = random(255);
    
  } 

  //drawRectangle
  fill( r, g, b);
  rect(rectX, rectY, rectWidth, rectHeight);

  //print("rand:" + rand);

  //is it inside the button
  if (
    mouseX > rectX - rectWidth / 2 &&
    mouseX < rectX + rectWidth / 2 &&
    mouseY > rectY - rectHeight / 2 &&
    mouseY < rectY + rectHeight / 2
  ) {
    bb = true;
  } else {
    //False
    bb = false;
    r=255;
    b=255;
    g=255;
  }
  print("bb:" + bb);

  x = x + 5;
}
