//An orbit
//Make the earth rotate around the sun
let angle=0
function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);
}

function draw() {
  //set background to blue
  background("#0E55A1");

  //sun
  translate(200,200)
  rotate(angle)
  
  
  
  fill("#E2BA15");
  noStroke();
  ellipseMode(CENTER)
  ellipse(0, 0, 100, 100);
  

  //earth
  rotate(angle)
  fill("#177E79");
  noStroke();
  ellipse(100, 100, 30, 30);
  
  angle=angle+1
}
