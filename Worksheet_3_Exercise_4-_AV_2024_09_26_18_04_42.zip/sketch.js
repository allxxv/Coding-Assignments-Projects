//simple drawing sketch

function setup() {
  createCanvas(400, 400);
  background(220);
}

function draw() {
  let pmouseX = mouseX; //put mouse X position into a variable
  let pmouseY = mouseY; //put mouse Y position into a variable
  pmouseX = mouseX; //put mouse X position into a variable
  pmouseY = mouseY; //put mouse Y position into a variable

  line(mouseX, mouseY, pmouseX, pmouseY); //draw a line from current mouse position to previous mouse position
}
