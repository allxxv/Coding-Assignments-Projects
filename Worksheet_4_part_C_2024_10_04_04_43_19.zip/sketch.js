let cvalue=0

function setup() {
  createCanvas(400, 400);
  background(230)
  rect(130,130,150,150);
  noLoop();
}

function draw() {}
 //rect(130,130,150,150);

function mouseClicked() {
  fill(0);
  rect(130,130,150,150);
}
if(cvalue==0){
  cvalue=255;
} else{
 cvalue=0
}
function doubleClicked() {
  fill(255);
  rect(130,130,150,150);
}