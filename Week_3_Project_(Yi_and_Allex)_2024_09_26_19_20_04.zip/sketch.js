let r, g, b;
let b1, b2, b3, b4;
let boxColor;
function setup() {
  createCanvas(windowWidth,windowHeight);
  background(0);
  let button = createButton("paint");
  button.mousePressed(brush1);
  // button.mouseReleased(brush1);

  let button2 = createButton("scale");
  button2.mousePressed(brush2);
  // button2.mouseReleased(brush2);

  let button3 = createButton("box");
  button3.mousePressed(brush3);
  //button.mouseReleased(brush3);

  let button4 = createButton("shape");
  button4.mousePressed(brush4);
  //button.mouseReleased(brush4);

  boxColor = color(245, 10, 90);
}

function draw() {
  r = random(255);
  g = random(255);
  b = random(255);

  if (b1) {
    brush1();
  }
  if (b2) {
    brush2();
  }
  if (b3) {
    brush3();
  }
  if (b4) {
    brush4();
  }
}

function brush1() {
  b1 = true;
  b2 = false;
  b3 = false;
  b4 = false;

  noStroke();
  fill(r, g, b, 50);
  ellipse(mouseX, mouseY, 24);

  function mousePressed() {
    ellipse(r, g, b, 255);
  }
}

function brush2() {
  b2 = true;
  b1 = false;
  b3 = false;
  b4 = false;

  noStroke();
  fill(r, g, b, 50);
  ellipse(mouseX, mouseY, 70);

  function mousePressed() {
    ellipse(r, g, b, 255);
  }
}
function brush3() {
  b2 = false;
  b1 = false;
  b3 = true;
  b4 = false;
  noStroke();
  fill(r, g, b, 24);
  rect(mouseX, mouseY, 24);
}

function mousePressed() {
  boxColor = color(random(255), random(255), random(255));
  noStroke();
  fill(r, g, b, 100);
  rect(mouseX, mouseY, 100);
}

function brush4() {
  b1 = false;
  b2 = false;
  b3 = false;
  b4 = true;
  noStroke();
  fill(r, g, b, 50);
  quad(
    mouseX,
    mouseY,
    mouseX + 24,
    mouseY,
    mouseX + 34,
    mouseY + 24,
    mouseX - 10,
    mouseY + 24
  );
}
